Info:
Camel to use in scene in the desert like in Egypt.
with UV materials in Blender, 
texture color available.

About author:
Modeled and textured by sielxm3d
Visit the web site: http://sielxm3d.co.nf