/*
 *  Final Project for CSCI 4229: Animals Around the World
 *  Citations: Willem Schreuder's examples from the course
 *  Author: Jennifer Michael
 *
 *  On startup, this program will display a graphic of the earth that can
 *  be manipulated using the arrow keys
 *  Continents on the globe can them be clicked with the mouse.
 *  When a continent is clicked, a scene of an animal from that region will
 *  be displayed in its environment.
 *  The user can then use the arrow keys to walk about in the environment
 *  The user can also press 'm' to exit the view of one environment and select another
 *
 *  Example: The user clicks Africa and the program will display a graphic of 2 elephants
 * 
 *  Key bindings:
 *  m          Exit out of one continent's environment to select another
 *  a          Toggle axes
 *  arrows     Change view angle
 *  PgDn/PgUp  Zoom in and out
 *  0          Reset view angle
 *  ESC        Exit
 */
#include "CSCIx229.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

/*Initialize arrays for skyboxes*/
int namerica[6];
int samerica[6];
int africa[6];
int asia[6];
int aussie[6];
int antartica[6];
int europe[6];

/*For the object associated with the selected continent*/
int obj;                      //  Object display list
int axes=0;                   //  Display axes
double scale;                 //  Scale to draw object files at
char* selection=NULL;         //  Name of the animal displayed
double r;                     //  Red color value
double b;                     //  Blue color value
double g;                     //  Green color value
int shader[4] = {0,0,0,0};    //  Shader
int click=0;                  //  Trigger to open up a second pane when a continent is clicked 
int mode =0;                  //  Shader mode

/*First person perspective variables*/
int th=0;      //  Azimuth of view angle
int ph=0;      //  Elevation of view angle
int rh=0;      //  Rotation of the eye (right/left)
int dh=0;      //  Rotation of the eye (up/down)
double x_pos = 0;
double y_pos = -10;
double z_pos = 10;
double x_dir = 0;
double y_dir = 0;
double z_dir = 0;

/*Perspective variables for view of globe*/
int fov=30;    //  Field of view
double asp=2;  //  Aspect ratio
double dim=2;  //  Size of world
int Width;
int Height;
int e_th;
int e_ph;

//For penguin and bear:
int inc       =   3;  // Ball increment
int emission  =   0;  // Emission intensity (%)
float shiny   =   4;  // Shininess (value)

//Captures mouse click coordinates
double ox=0.0,oy=0.0,oz=0.0;
unsigned int  banner_tex;
unsigned int m_tex;
unsigned int move_tex;
unsigned int fact;
#define TWOPI (2*M_PI)

//Define Earth parameters-- citation: Solar System example by Willem Schreuder
typedef struct
{
   char* name;
   char* ball;
   char* ring;
   unsigned int balltex;
   double  R;
   double rot;
   double th;
   double ph;
   double i,o,p,a,n,e,l;
}  Planet;
Planet earth = {
//   Name      Texture            Radius   Rotation      th     ph     i        o        p        a       n            e         l
   "Earth"  ,"earth.bmp"  ,0,0,   6378 ,     0.99 ,  -23.5,   0.0,  0.000007,6.094690,1.795101, 1.0000,0.0172016091,0.0166967,5.731723};

//Define Continent parameters
typedef struct
{
   char*  name;
   double xMin;                  //Coordinates on the globe to map the mouse clicks
   double xMax; 
   double yMin;
   double yMax;
   double zMin;
   double zMax;
   char*  animal;                //filepath to the obj file
   double scale;                 //scale at which to draw the object at
   double r;                     // r color value for object
   double g;                     // g color value for object
   double b;                     // b color value for object
   char* tex_path;
   unsigned int fact_tex;
} Continent;

Continent continents[7] = {
//   Name             xMin    xMax    yMin    yMax    zMin    zMax    animal                                     scale   r     g     b
   {"Africa",        -0.20,   0.60,  -0.95,  -0.75,  -0.50,   0.50,  "Animal_Objs/Elephant/3d-model.obj",        0.030,  0.430, 0.500, 0.560,  "Fact_Textures/africa_fact.bmp",0},
   {"Asia",           0.30,   0.90,  -0.30,   0.30,   0.30,   0.90,  "Animal_Objs/Camel/Camel_By_Sielxm3d.obj",  1.000,  0.700, 0.700, 0.400,  "Fact_Textures/asia_fact.bmp",0},
   {"Antartica",     -0.40,   0.40,  -0.40,   0.40,  -1.00,  -0.90,   NULL,                                      1.000,  1.000, 1.000, 1.000,  "Fact_Textures/antartica_fact.bmp",0},
   {"Europe",        -0.90,   0.29,  -0.80,  -0.50,   0.60,   0.80,  "Animal_Objs/Fox/fox.obj",                  1.000,  1.000, 0.600, 0.470,  "Fact_Textures/europe_fact.bmp",0},
   {"North America", -0.90,  -0.40,  -0.10,   0.40,   0.40,   0.80,   NULL,                                      1.000,  1.000, 1.000, 1.000,  "Fact_Textures/namerica_fact.bmp",0},
   {"South America", -0.90,  -0.60,  -0.70,  -0.20,  -0.70,   0.00,  "Animal_Objs/SNAKE/Snake_by_Swp.obj",       0.200,  0.500, 0.000, 0.000,  "Fact_Textures/samerica_fact.bmp",0},
   {"Australia",      0.45,   0.80,   0.4,    0.75,  -0.60,  -0.30,  "Animal_Objs/Frog/frog.obj",                1.000,  0.486, 0.980, 0.000,  "Fact_Textures/aussie_fact.bmp",0}

};

/*
 *  Draw vertex in polar coordinates
 */
static void Vertex(int th,int ph)
{
   double x = -Sin(th)*Cos(ph);
   double y =  Cos(th)*Cos(ph);
   double z =          Sin(ph);
   glNormal3d(x,y,z);
   glTexCoord2d(th/360.0,ph/180.0+0.5);
   glVertex3d(x,y,z);
}

/*
 *  Draw Earth
 */
void DrawEarth()
{
   int th,ph;

   /*
    *  Draw surface of the planet
    */
   //  Set texture
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D,earth.balltex);
   //  Latitude bands
   glColor3f(1,1,1);
   for (ph=-90;ph<90;ph+=5)
   {
      glBegin(GL_QUAD_STRIP);
      for (th=0;th<=360;th+=5)
      {
         Vertex(th,ph);
         Vertex(th,ph+5);
      }
      glEnd();
   }

   glDisable(GL_TEXTURE_2D);
}

/*
 * The following methods are used with drawing the bear found in North America
 *
 */

/* 
 * Draw legs
 *
 */
static void legs(double x, double y, double z) 
{
   //  Set specular color to white
   float white[] = {1,1,1,1};
   float black[] = {0,0,0,1};
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,white);
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,black);
   
   glPushMatrix();
   /*Move to relative location of bear-- each leg offset a bit*/
   glTranslated(x,y,z);
   
   /*Each leg is a rectangular prism*/
   glBegin(GL_QUADS);
   //  Front
   glNormal3f( 0, 0, 1);
   glVertex3f(-.1,-.4, .1);
   glVertex3f(+.1,-.4, .1);
   glVertex3f(+.1,+.4, .1);
   glVertex3f(-.1,+.4, .1);
   //  Back
   glNormal3f( 0, 0, -1);
   glVertex3f(+.1,-.4,-.1);
   glVertex3f(-.1,-.4,-.1);
   glVertex3f(-.1,+.4,-.1);
   glVertex3f(+.1,+.4,-.1);
   //  Right
   glNormal3f( 1, 1, 0);
   glVertex3f(+.1,-.4,-.1);
   glVertex3f(+.1,-.4,+.1);
   glVertex3f(+.1,-.4,-.1);
   glVertex3f(+.1,+.4,-.1);
   glVertex3f(+.1,+.4,+.1);
   //  Left .5);
   glNormal3f( 0, 1, 0);
   glVertex3f(-.1,-.4,-.1);
   glVertex3f(-.1,-.4,+.1);
   glVertex3f(-.1,+.4,+.1);
   glVertex3f(-.1,+.4,-.1);
   //  Top
   glNormal3f( 0, 1, 1);
   glVertex3f(-.1,+.4,+.1);
   glVertex3f(+.1,+.4,+.1);
   glVertex3f(+.1,+.4,-.1);
   glVertex3f(-.1,+.4,-.1);
   //  Bottom
   glNormal3f( 1, 0, 1);
   glVertex3f(-.1,-.4,-.1);
   glVertex3f(+.1,-.4,-.1);
   glVertex3f(+.1,-.4,+.1);
   glVertex3f(-.1,-.4,+.1);
   glEnd();
   glPopMatrix();
}

/*
 * 2D ellipse used in bear's eyes
 */
static void ellipse(double x, double y, double z, 
                     double xradius, double yradius)
{
   glPushMatrix();
   /*Move to relative location of this bear*/
   glTranslated(x, y, z);
   glBegin(GL_TRIANGLE_FAN);
   int i;
   /*Creates a 2d ellipse*/
   for(i=0; i<360; i++)
   {
      glVertex2f(Cos(i)*xradius, Sin(i)*yradius);
   }
   glEnd();
   glPopMatrix();
} 

/*
 *  Draw a ball
 *     at (x,y,z)
 *     radius (r)
 *  Used for bear's head and body as well as penguin eyes
 *
 */
static void ball(double x,double y,double z,double r)
{
   int th,ph;
   float white[] = {1.0,1.0,1.0,1.0};
   float Emission[]  = {0.0,0.0,0.01*emission,1.0};
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(r,r,r);
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,white);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);
   //  Bands of latitude
   for (ph=-90;ph<90;ph+=inc)
   {
      glBegin(GL_QUAD_STRIP);
      for (th=0;th<=360;th+=2*inc)
      {
         Vertex(th,ph);
         Vertex(th,ph+inc);
      }
      glEnd();
   }
   //  Undo transofrmations
   glPopMatrix();
}

/*
 * Draw bear
 *      at coords (x,y,z)
 *      dimension (dx, dy, dz)
 */
static void drawBear(double x, double y, double z, 
                    double dx, double dy, double dz)
{
   glPushMatrix();
   
   //Scale to size
   glScaled(dx, dy, dz);

   /*Draw the body!*/
   glColor3f(.35, .10, .040);
   //sphere(x,y,z, .6);
   ball(x,y,z, .6);
   /*Draw the head!*/
   glColor3f(.4, .16, .06);
  // sphere(x,y+(.2),z+(.6), .4);
   ball(x,y+(.2),z+(.6), .4);
   /*Draw the legs*/
   glColor3f(.4, .16, .06);
   ball(x,y+(.2),z+(.6), .4);
   legs(x-.25, y-.25,z-.25); 
   legs(x+.25, y-.25,z+.25);
   legs(x+.25, y-.25,z-.25);
   legs(x-.25, y-.25,z+.25);
   /*Draw the snout*/
   glColor3f(.45, .220, .10);
   ball(x, y+0.1,z+.9, .2);
   /*Draw the nose*/
   glColor3f(0,0,0);
   ball(x, y+0.1,z+1.1, .05);
   /*Draw the eyes*/
   ellipse(x-.1, y+.3, z+1,.051,.05);
   ellipse(x+.1, y+.3, z+1,.051, .05);
   /*Draw the ears*/
   glColor3f(.35, .10, .040);
   ball(x+0.2, y+0.550,z+0.50, .07);
   ball(x-0.2, y+0.550,z+0.50, .07);
   glPopMatrix();
}

/* The following methods are used to draw the penguin found in Antartica*/
/*
 * Draw ellipsoid
 * at (x,y,z)
 * with dimensions (rx,ry,rz)
 * scaled to r
 * Used for penguin body, wings, and feet
 */
static void ellipsoid(double x, double y, double z, double r, double rx, double ry, double rz, double d)
{
   int t,s;
   int tStep = inc;
   int sStep = inc*2;
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(r,r,r);
   glRotated(d, 1,0,0);
   //  Bands of latitude
   for(t = -90; t <90; t+=tStep)
   {
      glBegin(GL_TRIANGLE_STRIP);
      for(s=0; s <=360; s+=sStep)
      {
         //Calculate the vector so we can use it to find the normal
         double xPt = rx*Cos(t) * Cos(s);
         double yPt = ry*Cos(t) * Sin(s);
         double zPt = rz*Sin(t);
         //Calculate the normal and draw the point
         glNormal3d((xPt / (rx*rx)), (yPt / (ry*ry)), (zPt / (rz*rz)));
         glVertex3d(xPt, yPt, zPt);
         //Same for next increment
         double xPt2 = rx * Cos(t+tStep) * Cos(s);
         double yPt2 = ry * Cos(t+tStep) * Sin(s);
         double zPt2 = rz * Sin(t+tStep);
         glNormal3d((xPt2 / (rx*rx)), (yPt2 / (ry*ry)), (zPt2 / (rz*rz)));
         glVertex3d(xPt2, yPt2, zPt2);
      }
      glEnd();
   }
   //  Undo transofrmations
   glPopMatrix();
}  

/*
 * Draw pupil, which is just a 2d black cirle
 *
 */
static void pupil(double x, double y, double z, double r)
{
   glPushMatrix();
   glTranslated(x,y,z);
   glColor3f(0,0,0);
   glBegin(GL_TRIANGLE_FAN);
   int i;
   for(i=0; i<360; i++)
   {
      glVertex2f(Cos(i)*r, Sin(i)*r);
   }
   glEnd();
   glPopMatrix();
}

/*
 * Draw beak (cone)
 * z is the height of the cone, r is the radus.
 * x and y determine the coordinates
 *
 */
static void beak(double x, double y, double z, double r)
{
   //Scaling factors for the normals (use the height and the base)
   double cosn = ( z / sqrt ( z * z + r * r));
   double sinn = ( r   / sqrt ( z * z + r * r));
   glTranslated(x,y,z);
   glScaled(r,r,r);
   //Orange beak
   glColor3f(.98,.625,.12);
   glBegin(GL_TRIANGLES);
   int th;
   for(th = 0; th < 360; th+=inc)
   {
      //Normal is based off the angle, height, and base
      glNormal3d(Cos(th)*sinn, Sin(th)*sinn, cosn);
      glVertex3f(0,0,1);
      glVertex3f(Cos(th), Sin(th), 0);
      glVertex3f(Cos(th+inc), Sin(th+inc), 0);
   }
   glEnd();

} 

/*
 * Draw penguin at coords(x,y,z)
 */
static void drawPenguin(double x, double y, double z){
   //Chick body
   glColor3f(0.1,0.1,0.1);
   ellipsoid(x+0,y+0,z+0, .75, 1.2,2,1, 0);
   glColor3f(1,1,1);
   ellipsoid(x+0,y+0,z+.2, .70, 1,2,1, 0);
   //These are itty bitty wings
   glColor3f(0.1,0.1,0.1);
   ellipsoid(x-.9,y+0,z+0, .4, .25,.7,.5, 0);
   glColor3f(0.1,0.1,0.1);
   ellipsoid(x+.9,y+0,z+0,.4,.25,.7,.5,0);
   glColor3f(.98,.625,.12);
   ellipsoid(x-.4,y-1.2,z+.20, .4, .25, .7, .5, 90);
   glColor3f(.98,.625,.12);
   ellipsoid(x+.4, y-1.2, z+0.2, .4, .25, .7, .5, 90);
   //Eyes are made of pupils and balls
   pupil(x+.2,y+.6,z+.90, .05);
   pupil(x-.2,y+.6,z+.90,.05);
   glColor3f(1,1,1);
   ball(x-.2, y+.6, z+.70, .2);
   glColor3f(1,1,1);
   ball(x+.2, y+.6, z+.70, .2);
   //Beak is an orange cone
   glColor3f(.98,.625,.12);
   beak(x+0,y+.25,z+.7,.4);
}

void Directions()
{ 
   //  Save transform attributes (Matrix Mode and Enabled Modes)
   glPushAttrib(GL_TRANSFORM_BIT|GL_ENABLE_BIT);
   //  Save projection matrix and set unit transform
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   glOrtho(-asp,+asp,-1,1,-1,1);
   //  Save model view matrix and set to indentity
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   glLoadIdentity();
   //  Draw instrument panel with texture
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, banner_tex);
   glBegin(GL_QUADS);
   glTexCoord2d(0,1);glVertex2f(-2,1);
   glTexCoord2d(1,1);glVertex2f(+2,1);
   glTexCoord2d(1,0);glVertex2f(+2, .5);
   glTexCoord2d(0,0);glVertex2f(-2, .5);
   glEnd();
   glDisable(GL_TEXTURE_2D);
   //  Reset model view matrix
   glPopMatrix();
   //  Reset projection matrix
   glMatrixMode(GL_PROJECTION);
   glPopMatrix();
   //  Pop transform attributes (Matrix Mode and Enabled Modes)
   glPopAttrib();
}

void DisplayFacts()
{ 
   //  Save transform attributes (Matrix Mode and Enabled Modes)
   glPushAttrib(GL_TRANSFORM_BIT|GL_ENABLE_BIT);
   //  Save projection matrix and set unit transform
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   glOrtho(-asp,+asp,-1,1,-1,1);
   //  Save model view matrix and set to indentity
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   glLoadIdentity();
   //  Draw instrument panel with texture
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, fact);
   glBegin(GL_QUADS);
   glTexCoord2d(0,1);glVertex2f(-2,1);
   glTexCoord2d(1,1);glVertex2f(+2,1);
   glTexCoord2d(1,0);glVertex2f(+2, .5);
   glTexCoord2d(0,0);glVertex2f(-2, .5);
   glEnd();
   glDisable(GL_TEXTURE_2D);
   
   //  Reset model view matrix
   glPopMatrix();
   //  Reset projection matrix
   glMatrixMode(GL_PROJECTION);
   glPopMatrix();
   //  Pop transform attributes (Matrix Mode and Enabled Modes)
   glPopAttrib();
}

void DisplayM()
{ 
   //  Save transform attributes (Matrix Mode and Enabled Modes)
   glPushAttrib(GL_TRANSFORM_BIT|GL_ENABLE_BIT);
   //  Save projection matrix and set unit transform
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   glOrtho(-asp,+asp,-1,1,-1,1);
   //  Save model view matrix and set to indentity
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   glLoadIdentity();
   //  Draw instrument panel with texture
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, m_tex);
   glBegin(GL_QUADS);
   glTexCoord2d(0,1);glVertex2f(-2,-.75);
   glTexCoord2d(1,1);glVertex2f(-1.25,-.75);
   glTexCoord2d(1,0);glVertex2f(-1.25, -1);
   glTexCoord2d(0,0);glVertex2f(-2, -1);
   glEnd();
   glDisable(GL_TEXTURE_2D);
   
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, move_tex);
   glBegin(GL_QUADS);
   glTexCoord2d(0,1);glVertex2f(1.25,-.75);
   glTexCoord2d(1,1);glVertex2f(2,-.75);
   glTexCoord2d(1,0);glVertex2f(2, -1);
   glTexCoord2d(0,0);glVertex2f(1.25, -1);
   glEnd();
   glDisable(GL_TEXTURE_2D);
   
   //  Reset model view matrix
   glPopMatrix();
   //  Reset projection matrix
   glMatrixMode(GL_PROJECTION);
   glPopMatrix();
   //  Pop transform attributes (Matrix Mode and Enabled Modes)
   glPopAttrib();
}
/*Draw the Skybox based off what continent the user clicked!*/
static void Sky(double D)
{
   int sky[6];
   for(int i = 0; i <= 5; i++){
      if(!strcmp(selection, "North America"))
         sky[i] = namerica[i];
      if(!strcmp(selection, "Europe"))
         sky[i] = namerica[i];
      if(!strcmp(selection,"Africa"))
         sky[i] = africa[i];
      if(!strcmp(selection,"South America"))
         sky[i] = samerica[i];
      if(!strcmp(selection,"Asia"))
         sky[i] = asia[i];
      if(!strcmp(selection, "Antartica"))
         sky[i] = antartica[i];
      if(!strcmp(selection, "Australia"))
         sky[i] = aussie[i];
   }
   glColor3f(1,1,1);
   glEnable(GL_TEXTURE_2D);

   //  Sides
   glBindTexture(GL_TEXTURE_2D,sky[5]);
   glBegin(GL_QUADS);
   glTexCoord2f(0.00,0); glVertex3f(-D,-D,-D);
   glTexCoord2f(1,0); glVertex3f(+D,-D,-D);
   glTexCoord2f(1,1); glVertex3f(+D,+D,-D);
   glTexCoord2f(0.00,1); glVertex3f(-D,+D,-D);
   glEnd();
   
   glBindTexture(GL_TEXTURE_2D, sky[3]);
   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex3f(+D,-D,-D);
   glTexCoord2f(1,0); glVertex3f(+D,-D,+D);
   glTexCoord2f(1,1); glVertex3f(+D,+D,+D);
   glTexCoord2f(0.0,1); glVertex3f(+D,+D,-D);
   glEnd();

   glBindTexture(GL_TEXTURE_2D, sky[2]);
   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex3f(+D,-D,+D);
   glTexCoord2f(1,0); glVertex3f(-D,-D,+D);
   glTexCoord2f(1,1); glVertex3f(-D,+D,+D);
   glTexCoord2f(0,1); glVertex3f(+D,+D,+D);
   glEnd();

   glBindTexture(GL_TEXTURE_2D, sky[0]);
   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex3f(-D,-D,+D);
   glTexCoord2f(1,0); glVertex3f(-D,-D,-D);
   glTexCoord2f(1,1); glVertex3f(-D,+D,-D);
   glTexCoord2f(0,1); glVertex3f(-D,+D,+D);
   glEnd();

   //  Top and bottom
   glBindTexture(GL_TEXTURE_2D,sky[4]);
   glBegin(GL_QUADS);
   glTexCoord2f(0.0,0); glVertex3f(+D,+D,-D);
   glTexCoord2f(1,0); glVertex3f(+D,+D,+D);
   glTexCoord2f(1,1); glVertex3f(-D,+D,+D);
   glTexCoord2f(0.0,1); glVertex3f(-D,+D,-D);
   glEnd();

   glBindTexture(GL_TEXTURE_2D,sky[1]);
   glBegin(GL_QUADS);
   glTexCoord2f(0.0,0); glVertex3f(-D,-D,+D);
   glTexCoord2f(1,0); glVertex3f(+D,-D,+D);
   glTexCoord2f(1,1); glVertex3f(+D,-D,-D);
   glTexCoord2f(0,1); glVertex3f(-D,-D,-D);
   glEnd();

   glDisable(GL_TEXTURE_2D);
}

/*
 *  OpenGL (GLUT) calls this routine to display the scene
 */
void display()
{
   //  Length of axes
   const double len=2.0;  //  Length of axes
   //  Light position and colors
   float Emission[]  = {0.0,0.0,0.0,1.0};
   float Ambient[]   = {0.3,0.3,0.3,1.0};
   float Diffuse[]   = {1.0,1.0,1.0,1.0};
   float Specular[]  = {1.0,1.0,1.0,1.0};
   //Directional Lighting
   float Position[] = {-20,20,-10,10};
   float Shinyness[] = {16};

   //  Eye position
   double Ex = -2*dim*Sin(e_th)*Cos(e_ph);
   double Ey = +2*dim*Sin(e_ph);
   double Ez = +2*dim*Cos(e_th)*Cos(e_ph);
   //  Erase the window and the depth buffer
   //  Erase the window and the depth buffer
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

   //  Enable Z-buffering in OpenGL
   glEnable(GL_DEPTH_TEST);
   //  Undo previous transformations
   glLoadIdentity();
   
   /*If a continent was clicked, we split the window to show the scene*/
   if(click)
  {
      Project(60,asp/2,dim);
      glViewport(0,0,Width/2,Height);
   }
   else
   {
      Project(60,asp,dim);
      glViewport(0,0,Width,Height);
   }
   //  Rotate Z up
   gluLookAt(Ex,Ey,Ez , 0,0,0 , 0,Cos(e_ph),0);
   glRotated(-90,1,0,0);

   /*
    *  Draw Earth
    */
    glRotated(e_ph,1,0,0);  // Declination
    glRotated(e_th,0,0,1);  // Spin around axes
    DrawEarth();
   
   //Draw directions over top
   Directions();

   /*
    *  Draw axes - no textures from here
    */
   glColor3f(1,1,1);
   if (axes)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,len);
      glEnd();
      //  Label axes
      glRasterPos3d(len,0.0,0.0);
      Print("X");
      glRasterPos3d(0.0,len,0.0);
      Print("Y");
      glRasterPos3d(0.0,0.0,len);
      Print("Z");
   }

   /*What happens if a continent is clicked*/
   if (click)
   {
      //First, split our window to open up the scene in the right half
      int ix=Width/2+1,iy=Height-5;
      Project(0,asp/2,dim);
      glViewport(Width/2+1,0,Width/2,Height);
      glWindowPos2i(ix,iy-=20);
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      //Get ready to draw skybox with fog
      glDepthFunc(GL_LEQUAL);
      glEnable(GL_DEPTH_TEST);
      GLfloat fogColor[4] = {0.5f, 0.5f, 0.5f, 1.0f};
      glEnable(GL_FOG);
      {
         glFogi(GL_FOG_MODE, GL_EXP);
         glFogfv(GL_FOG_COLOR, fogColor);
         glFogf(GL_FOG_DENSITY, 0.04);
         glHint(GL_FOG_HINT, GL_DONT_CARE);
         glFogf(GL_FOG_START, 1.0);
         glFogf(GL_FOG_END, 20.0f);
      }

      gluPerspective(100.0, Width/Height, 0.01f, 100.0);  
      //Set up initial position for first person navigation 
      x_dir = +2*dim*Sin(rh);
      y_dir = +2*dim*Sin(dh);
      z_dir = -2*dim*Cos(rh);
      gluLookAt(x_pos, y_pos, z_pos, x_dir+x_pos, y_pos+y_dir, z_dir+z_pos, 0,1, 0);

      //Draw the skybox
      Sky(dim*10); 
      DisplayFacts();
      DisplayM();
      //  OpenGL should normalize normal vectors
      glEnable(GL_NORMALIZE);
      //  Enable lighting
      glEnable(GL_LIGHTING);
      glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
      glEnable(GL_COLOR_MATERIAL);
      //  Enable light 0
      glEnable(GL_LIGHT0);
      //  Set ambient, diffuse, specular components and position of light 0
      glLightfv(GL_LIGHT0,GL_AMBIENT ,Ambient);
      glLightfv(GL_LIGHT0,GL_DIFFUSE ,Diffuse);
      glLightfv(GL_LIGHT0,GL_SPECULAR,Specular);
      glLightfv(GL_LIGHT0,GL_POSITION,Position);
      //  Set materials
      glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,Shinyness);
      glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,Specular);
      glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,Emission);

      //  Draw the model

      // I drew the penguin myself, so we have a different routine here
      if(!strcmp(selection,"Antartica"))
         drawPenguin(0,-12,5);
      // I drew the bear myself, so we have a different routine here
      else if(!strcmp(selection,"North America")){
         drawBear(0,-3,-2, 5,5,5);
         drawBear(-2,-7,-1.5,2,2,2);
      }

      // Otherwise, we want to load in the respective obj model for that continent
      else{
         //Use per pixel shader here to make low-poly objs look better
         glUseProgram(shader[mode]);
         glColor3f(r,g,b);
         
         //Draw the mama
         glPushMatrix();
         glTranslatef(0,-18,-5);
         glRotatef(0, 0,1,0);
         glScalef(scale, scale, scale);
         glCallList(obj);
         glPopMatrix();
         
         //Draw the baby
         glPushMatrix();
         glTranslatef(-2,-18,0);
         glRotatef(-50,0,1,0);
         glScalef(.3*scale, .3*scale, .3*scale);
         glCallList(obj);
         glPopMatrix();
      }
      glDisable(GL_DEPTH_TEST);
      glDisable(GL_LIGHTING);
      glDisable(GL_LIGHT0);
      glDisable(GL_FOG);
      glWindowPos2i(5,5);
      glWindowPos2i(5,5);
      //Print("x_pos=%f, z_pos=%f", x_pos, z_pos);
   }
   
        glUseProgram(0);
//  Display parameters
   glWindowPos2i(5,5);
   //Print("X=%f, Y=%f, Z=%f, Selection=%s", ox, oy, oz, selection);
   //  Render the scene and make it visible
   ErrCheck("display");
   glFlush();
   glutSwapBuffers();
}

/*
 * Captures mouse clicks and sets globals so we know what to display
 */
void Mouse(int button,int state,int x,int y) {
  GLint viewport[4];
  GLdouble modelview[16],projection[16];
  GLfloat wx=x,wy,wz;

  if(state != GLUT_DOWN){
    int k;
    for(k = 0; k <= 6; k++){
       if(ox >= continents[k].xMin && ox <= continents[k].xMax &&
          oy >= continents[k].yMin && oy <= continents[k].yMax &&
          oz >= continents[k].zMin && oz <= continents[k].zMax){
          click = 1-click;
          selection = continents[k].name;
          fact  = continents[k].fact_tex;
          if(continents[k].animal != NULL){
             obj = LoadOBJ(continents[k].animal);
             scale = continents[k].scale;
             r = continents[k].r;
             g = continents[k].g;
             b = continents[k].b;
          }
  }}}
  glGetIntegerv(GL_VIEWPORT,viewport);
  y=viewport[3]-y;
  wy=y;
  glGetDoublev(GL_MODELVIEW_MATRIX,modelview);
  glGetDoublev(GL_PROJECTION_MATRIX,projection);
  glReadPixels(x,y,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&wz);
  gluUnProject(wx,wy,wz,modelview,projection,viewport,&ox,&oy,&oz);
  glutPostRedisplay();
}

/*
 *  GLUT calls this routine when an arrow key is pressed
 */
void special(int key,int x,int y)
{
   //  Right arrow key - increase angle by 5 degrees
   if (key == GLUT_KEY_RIGHT)
      if(click){
         //First person nav only used within animal scene
         if(x_pos < 15 && x_pos >= -15){
            if((x_pos-(z_dir * 0.05)) < 15){
               x_pos -= z_dir * 0.05;
               z_pos += x_dir * 0.05;
      }}}else
         e_th += 5;
   //  Left arrow key - decrease angle by 5 degrees
   else if (key == GLUT_KEY_LEFT)
      if(click){
         //First person nav only used within animal scene
         if(x_pos >= -15 && x_pos < 15){
            if((x_pos+(z_dir * 0.05)) > -15){
               x_pos += z_dir * 0.05;
               z_pos -= x_dir * 0.05;
      }}}else
         e_th -= 5;
   //  Up arrow key - increase elevation by 5 degrees
   else if (key == GLUT_KEY_UP)
      if(click){
         //First person nav only used within animal scene
         if(z_pos >=-15 && z_pos < 15){
            if((z_pos+(z_dir * 0.05)) > -15){
            x_pos += x_dir * 0.05;
            z_pos += z_dir * 0.05;
      }}}else
         e_ph += 5;
   //  Down arrow key - decrease elevation by 5 degrees
   else if (key == GLUT_KEY_DOWN)
      if(click){
         //First person nav only used within animal scene
         if(z_pos < 15 && z_pos >= -15){
            if((z_pos-(z_dir * 0.05)) < 15){
            x_pos -= x_dir * 0.05;
            z_pos -= z_dir * 0.05;
      }}}else
         e_ph -= 5;
   //  PageUp key - increase dim
   else if (key == GLUT_KEY_PAGE_DOWN && !click)
      dim += 0.1;
   //  PageDown key - decrease dim
   else if (key == GLUT_KEY_PAGE_UP && dim>0.5)
      dim -= 0.1;
   //  Keep angles to +/-360 degrees
   e_th %= 360;
   e_ph %= 360;
   //  Update projection
   Project(fov,asp,dim);
   //  Tell GLUT it is necessary to redisplay the scene
   glutPostRedisplay();
}

void SetMode(int k)
{
   e_th = earth.th;
   e_ph = earth.ph;
}
/*
 *  GLUT calls this routine when the window is resized
 */
void idle()
{
   glutPostRedisplay();
}

/*
 *  GLUT calls this routine when a key is pressed
 */
void key(unsigned char ch,int x,int y)
{
   //  Exit on ESC
   if (ch == 27)
      exit(0);
   //  Toggle axes
   else if (ch == 'x' || ch == 'X')
      axes = 1-axes;
   else if (ch == 'm' || ch == 'M'){
      click = 1-click;
      //Reset eye position 
      rh = 0;  dh = 0;
      x_pos = 0; y_pos = -10; z_pos = 10;
      x_dir = 0; y_dir = 0; z_dir = 0;
   }
   else if (ch == 'a')
      rh -=3;
   else if (ch == 'd')
      rh += 3;
   else if (ch == 'w')
      dh += 3;
   else if (ch == 's')
      dh -= 3;
   //  Reproject
   Project(fov,asp,dim);
   //  Tell GLUT it is necessary to redisplay the scene
   glutPostRedisplay();
}

/*
 *  GLUT calls this routine when the window is resized
 */
void reshape(int width,int height)
{
   //  Ratio of the width to the height of the window
   asp = (height>0) ? (double)width/height : 1;
   //  Set the viewport to the entire window
   glViewport(0,0, width,height);
   //  Set projection
   Project(fov,asp,dim);
   Width = width;
   Height = height;
}

/*
 *  Read text file
 */
char* ReadText(char *file)
{
   int   n;
   char* buffer;
   //  Open file
   FILE* f = fopen(file,"rt");
   if (!f) Fatal("Cannot open text file %s\n",file);
   //  Seek to end to determine size, then rewind
   fseek(f,0,SEEK_END);
   n = ftell(f);
   rewind(f);
   //  Allocate memory for the whole file
   buffer = (char*)malloc(n+1);
   if (!buffer) Fatal("Cannot allocate %d bytes for text file %s\n",n+1,file);
   //  Snarf the file
   if (fread(buffer,n,1,f)!=1) Fatal("Cannot read %d bytes for text file %s\n",n,file);
   buffer[n] = 0;
   //  Close and return
   fclose(f);
   return buffer;
}

/*
 *  Print Shader Log
 */
void PrintShaderLog(int obj,char* file)
{
   int len=0;
   glGetShaderiv(obj,GL_INFO_LOG_LENGTH,&len);
   if (len>1)
   {
      int n=0;
      char* buffer = (char *)malloc(len);
      if (!buffer) Fatal("Cannot allocate %d bytes of text for shader log\n",len);
      glGetShaderInfoLog(obj,len,&n,buffer);
      fprintf(stderr,"%s:\n%s\n",file,buffer);
      free(buffer);
   }
   glGetShaderiv(obj,GL_COMPILE_STATUS,&len);
   if (!len) Fatal("Error compiling %s\n",file);
}

/*
 *  Print Program Log
 */
void PrintProgramLog(int obj)
{
   int len=0;
   glGetProgramiv(obj,GL_INFO_LOG_LENGTH,&len);
   if (len>1)
   {
      int n=0;
      char* buffer = (char *)malloc(len);
      if (!buffer) Fatal("Cannot allocate %d bytes of text for program log\n",len);
      glGetProgramInfoLog(obj,len,&n,buffer);
      fprintf(stderr,"%s\n",buffer);
   }
   glGetProgramiv(obj,GL_LINK_STATUS,&len);
   if (!len) Fatal("Error linking program\n");
}
int CreateShader(GLenum type,char* file)
{
   //  Create the shader
   int shader = glCreateShader(type);
   //  Load source code from file
   char* source = ReadText(file);
   glShaderSource(shader,1,(const char**)&source,NULL);
   free(source);
   //  Compile the shader
   fprintf(stderr,"Compile %s\n",file);
   glCompileShader(shader);
   //  Check for errors
   PrintShaderLog(shader,file);
   //  Return name
   return shader;
}

/*
 *  Create Shader Program
 */
int CreateShaderProg(char* VertFile,char* FragFile)
{
   //  Create program
   int prog = glCreateProgram();
   //  Create and compile vertex shader
   int vert = CreateShader(GL_VERTEX_SHADER  ,VertFile);
   //  Create and compile fragment shader
   int frag = CreateShader(GL_FRAGMENT_SHADER,FragFile);
   //  Attach vertex shader
   glAttachShader(prog,vert);
   //  Attach fragment shader
   glAttachShader(prog,frag);
   //  Link program
   glLinkProgram(prog);
   //  Check for errors
   PrintProgramLog(prog);
   //  Return name
   return prog;
}
/*
 *  Start up GLUT and tell it what to do
 */
int main(int argc,char* argv[])
{

   //  Initialize GLUT
   glutInit(&argc,argv);
   //  Request double buffered, true color window with Z buffering at 600x600
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE | GLUT_ALPHA);
   glutInitWindowSize(1500,1000);
   glutCreateWindow("Jenny Michael: Final Project");
   //  Set callbacks
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutSpecialFunc(special);
   glutKeyboardFunc(key);
   glutMouseFunc(Mouse);
   glutIdleFunc(idle);

   //  Load textures
   earth.balltex = LoadTexBMP(earth.ball);
   banner_tex = LoadTexBMP("Fact_Textures/welcome_banner.bmp");
   m_tex = LoadTexBMP("Fact_Textures/m_direction.bmp");
   move_tex = LoadTexBMP("Fact_Textures/move_direction.bmp");
   for(int i = 0; i<=6; i++){
      continents[i].fact_tex = LoadTexBMP(continents[i].tex_path);
   }

   namerica[0] = LoadTexBMP("forest_sky_box/forest_1.bmp");
   namerica[1] = LoadTexBMP("forest_sky_box/forest_2.bmp");
   namerica[2] = LoadTexBMP("forest_sky_box/forest_3.bmp");
   namerica[3] = LoadTexBMP("forest_sky_box/forest_4.bmp");
   namerica[4] = LoadTexBMP("forest_sky_box/forest_5.bmp");
   namerica[5] = LoadTexBMP("forest_sky_box/forest_6.bmp");
   
   africa[0] = LoadTexBMP("africa_sky_box/africa_left.bmp");
   africa[1] = LoadTexBMP("africa_sky_box/africa_bottom.bmp");
   africa[2] = LoadTexBMP("africa_sky_box/africa_front.bmp");
   africa[3] = LoadTexBMP("africa_sky_box/africa_right.bmp");
   africa[4] = LoadTexBMP("africa_sky_box/africa_top.bmp");
   africa[5] = LoadTexBMP("africa_sky_box/africa_back.bmp");
  
   samerica[0] = LoadTexBMP("amazon_sky_box/amazon_left.bmp");
   samerica[1] = LoadTexBMP("amazon_sky_box/amazon_bottom.bmp");
   samerica[2] = LoadTexBMP("amazon_sky_box/amazon_front.bmp");
   samerica[3] = LoadTexBMP("amazon_sky_box/amazon_right.bmp");
   samerica[4] = LoadTexBMP("amazon_sky_box/amazon_top.bmp");
   samerica[5] = LoadTexBMP("amazon_sky_box/amazon_back.bmp");

   asia[0] = LoadTexBMP("asia_sky_box/asia_left.bmp");
   asia[1] = LoadTexBMP("asia_sky_box/asia_bottom.bmp");
   asia[2] = LoadTexBMP("asia_sky_box/asia_front.bmp");
   asia[3] = LoadTexBMP("asia_sky_box/asia_right.bmp");
   asia[4] = LoadTexBMP("asia_sky_box/asia_top.bmp");
   asia[5] = LoadTexBMP("asia_sky_box/asia_back.bmp");
    
   aussie[0] = LoadTexBMP("aussie_sky_box/aussie_left.bmp");
   aussie[1] = LoadTexBMP("aussie_sky_box/aussie_bottom.bmp");
   aussie[2] = LoadTexBMP("aussie_sky_box/aussie_front.bmp");
   aussie[3] = LoadTexBMP("aussie_sky_box/aussie_right.bmp");
   aussie[4] = LoadTexBMP("aussie_sky_box/aussie_top.bmp");
   aussie[5] = LoadTexBMP("aussie_sky_box/aussie_back.bmp");
   
   antartica[0] = LoadTexBMP("ant_sky_box/ant_left.bmp");
   antartica[1] = LoadTexBMP("ant_sky_box/ant_bottom.bmp");
   antartica[2] = LoadTexBMP("ant_sky_box/ant_front.bmp");
   antartica[3] = LoadTexBMP("ant_sky_box/ant_right.bmp");
   antartica[4] = LoadTexBMP("ant_sky_box/ant_top.bmp");
   antartica[5] = LoadTexBMP("ant_sky_box/ant_back.bmp");
   
   shader[0] = CreateShaderProg("pixlight.vert", "pixlight.frag");
   SetMode(0);

   //  Pass control to GLUT so it can interact with the user
   ErrCheck("init");
   glutMainLoop();
   return 0;
}
