#ifndef LiangBarsky
#define LiangBarsky
int  ClipLB(double& x0,double& y0,double& x1,double& y1);
#endif
